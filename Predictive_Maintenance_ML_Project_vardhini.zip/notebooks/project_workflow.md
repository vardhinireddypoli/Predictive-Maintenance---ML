
# Workflow
1. Generate Dataset
2. Perform EDA
3. Visualize Data
4. Train Models
5. Evaluate Performance
6. Present Results
