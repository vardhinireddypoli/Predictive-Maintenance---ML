
import pandas as pd, numpy as np
np.random.seed(42)
n=5000
df=pd.DataFrame({
'Machine_ID':range(1,n+1),
'Temperature':np.random.normal(70,10,n),
'Pressure':np.random.normal(100,15,n),
'Vibration':np.random.normal(5,2,n),
'Humidity':np.random.uniform(30,90,n),
'Running_Hours':np.random.randint(100,10000,n),
'Power_Consumption':np.random.normal(500,80,n),
'Maintenance_History':np.random.randint(0,10,n),
'Machine_Type':np.random.choice(['A','B','C'],n)
})
risk=(df['Temperature']>80).astype(int)+(df['Pressure']>120).astype(int)+(df['Vibration']>7).astype(int)
df['Failure_Status']=(risk>=2).astype(int)
df.to_csv('data/machine_data.csv',index=False)
print('Dataset saved')
