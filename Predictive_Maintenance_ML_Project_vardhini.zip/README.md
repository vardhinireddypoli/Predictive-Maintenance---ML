
# Predictive Maintenance for Industrial Machines

## Problem Statement
Predict machine failures using sensor and operational data.

## Features
Temperature, Pressure, Vibration, Humidity, Running Hours,
Power Consumption, Maintenance History, Machine Type.

## Target
Failure_Status (0 = Healthy, 1 = Failure)
