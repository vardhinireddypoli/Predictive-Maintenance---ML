
import pandas as pd
import matplotlib.pyplot as plt
import os
os.makedirs('outputs',exist_ok=True)

df=pd.read_csv('data/machine_data.csv')

plt.figure()
df['Failure_Status'].value_counts().plot(kind='bar')
plt.title('Failure Distribution')
plt.savefig('outputs/failure_distribution.png')
